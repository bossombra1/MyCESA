<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class NoteController extends ApiController
{
    public function index(Request $request)
    {
        $notes     = $this->getData('/notes');
        $etudiants = $this->getData('/etudiants');

        // Recherche
        if ($search = $request->get('search')) {
            $s = strtolower($search);
            $notes = array_filter($notes, fn($n) =>
                str_contains(strtolower($n['Nom_Complet'] ?? ''), $s) ||
                str_contains(strtolower($n['Matricule_Etudiant'] ?? ''), $s)
            );
        }

        // Grouper par étudiant (une ligne par étudiant)
        $parEtudiant = [];
        foreach ($notes as $n) {
            $matricule = $n['Matricule_Etudiant'] ?? 'inconnu';
            if (!isset($parEtudiant[$matricule])) {
                $parEtudiant[$matricule] = [
                    'matricule'   => $matricule,
                    'nom_complet' => $n['Nom_Complet'] ?? '—',
                    'notes'       => [],
                ];
            }
            $parEtudiant[$matricule]['notes'][] = $n;
        }

        // Calculer moyenne générale par étudiant
        foreach ($parEtudiant as &$etudiant) {
            $vals = array_filter(
                array_map(fn($n) => floatval($n['Note_Evaluation'] ?? 0), $etudiant['notes']),
                fn($v) => $v > 0
            );
            $etudiant['nb_notes']  = count($etudiant['notes']);
            $etudiant['moyenne']   = count($vals) ? round(array_sum($vals) / count($vals), 2) : null;
        }

        return view('notes.index', compact('parEtudiant'));
    }

    public function show($matricule)
    {
        $notes = $this->getData('/notes');

        // Filtrer les notes de cet étudiant
        $notesEtudiant = array_filter($notes, fn($n) =>
            ($n['Matricule_Etudiant'] ?? '') === $matricule
        );

        if (empty($notesEtudiant)) {
            return back()->with('error', 'Aucune note trouvée pour cet étudiant.');
        }

        $first       = array_values($notesEtudiant)[0];
        $nomComplet  = $first['Nom_Complet'] ?? '—';

        // Grouper par semestre puis par matière
        $parSemestre = [];
        foreach ($notesEtudiant as $n) {
            $sem     = $n['Semestre'] ?? 'Semestre 1';
            $matiere = $n['Nom_Matiere'] ?? 'Matière inconnue';
            if (!isset($parSemestre[$sem])) $parSemestre[$sem] = [];
            if (!isset($parSemestre[$sem][$matiere])) $parSemestre[$sem][$matiere] = [];
            $parSemestre[$sem][$matiere][] = $n;
        }

        // Calculer moyennes par matière (pondérée par coef) et moyenne générale par semestre
        $stats = [];
        foreach ($parSemestre as $sem => $matieres) {
            $moyennesParMatiere = [];
            foreach ($matieres as $mat => $notesM) {
                $totalPts  = 0;
                $totalCoef = 0;
                foreach ($notesM as $n) {
                    $val  = floatval($n['Note_Evaluation'] ?? 0);
                    $coef = floatval($n['Coef_Evaluation'] ?? 1);
                    $totalPts  += $val * $coef;
                    $totalCoef += $coef;
                }
                $moy = $totalCoef > 0 ? round($totalPts / $totalCoef, 2) : null;
                $moyennesParMatiere[$mat] = $moy;
            }

            // Moyenne générale du semestre = moyenne des moyennes par matière
            $vals   = array_filter($moyennesParMatiere, fn($v) => $v !== null);
            $moyGen = count($vals) ? round(array_sum($vals) / count($vals), 2) : null;

            $stats[$sem] = [
                'moyennes_par_matiere' => $moyennesParMatiere,
                'moyenne_generale'     => $moyGen,
                'mention'              => $this->getMention($moyGen),
            ];
        }

        return view('notes.show', compact('notesEtudiant', 'parSemestre', 'stats', 'nomComplet', 'matricule'));
    }

    private function getMention($note): array
    {
        if ($note === null) return [];
        if ($note >= 16) return ['txt' => 'Très Bien',   'color' => 'success'];
        if ($note >= 14) return ['txt' => 'Bien',        'color' => 'success'];
        if ($note >= 12) return ['txt' => 'Assez Bien',  'color' => 'warning'];
        if ($note >= 10) return ['txt' => 'Passable',    'color' => 'warning'];
        return              ['txt' => 'Insuffisant',     'color' => 'danger'];
    }
}
