<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Session;

class ApiController extends Controller
{
    protected function api()
    {
        return Http::timeout((int) env('API_TIMEOUT', 10))
            ->withHeaders([
                'Authorization' => 'Bearer ' . Session::get('jwt_token'),
                'Accept'        => 'application/json',
                'Content-Type'  => 'application/json',
            ])
            ->baseUrl(env('NODE_API_URL', 'http://localhost:8080/api'));
    }

    /**
     * Récupère une liste depuis l'API.
     * Gère automatiquement les structures : [], {data:[]}, {data:{items:[]}}
     */
    protected function getData(string $endpoint): array
    {
        try {
            $response = $this->api()->get($endpoint);
            if ($response->successful()) {
                $json = $response->json();

                // Cas 1 : tableau direct []
                if (is_array($json) && isset($json[0])) {
                    return $json;
                }
                // Cas 2 : { data: [...] }
                if (isset($json['data']) && is_array($json['data'])) {
                    $data = $json['data'];
                    // Cas 3 : { data: { items: [...] } }
                    if (isset($data[0])) return $data;
                    foreach ($data as $v) {
                        if (is_array($v)) return $data;
                    }
                }
                // Cas 4 : { items: [...] } ou autre clé contenant un tableau
                foreach ($json as $key => $value) {
                    if (is_array($value) && count($value) > 0 && isset($value[0])) {
                        return $value;
                    }
                }
                // Cas 5 : objet unique (ex: GET /etudiants/1)
                if (is_array($json) && !empty($json)) {
                    return $json;
                }
                return [];
            }
            return [];
        } catch (\Exception $e) {
            return [];
        }
    }

    /**
     * Récupère un objet unique depuis l'API (ex: GET /etudiants/1).
     * Gère { data: {...} } ou directement {...}
     */
    protected function getOne(string $endpoint): array
    {
        try {
            $response = $this->api()->get($endpoint);
            if ($response->successful()) {
                $json = $response->json();
                // { data: {...} }
                if (isset($json['data']) && is_array($json['data'])) {
                    return $json['data'];
                }
                // Tableau direct
                if (is_array($json)) {
                    return $json;
                }
            }
            return [];
        } catch (\Exception $e) {
            return [];
        }
    }

    protected function handleApiError(\Exception $e, string $action = 'effectuer cette action')
    {
        return back()->with('error', "Impossible de {$action}. Verifiez que l'API est disponible.");
    }
}
